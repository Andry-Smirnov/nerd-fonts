
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 81e7be81f88d00dcfda062e22e366636102911ae
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Mon Mar 18 23:47:58 2024 +0000
        
            [ci] Update FontPatcher.zip
